/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{html,js}"],
  theme: {
    minWidth: {
      '1/8': '12%',
    },
    extend: {
      colors: {
        clifford: '#da373d',
        bggrey: '#F5F5F5',
        bggrey2: '#ECECEC',
        paleg: '#81BC00',
        darkg: '#018136',
      },
      backgroundImage: {
        'bgnav': "url('/graphics/zielona-tło_1.png')",

      }
    },
  },
  plugins: [],
}

