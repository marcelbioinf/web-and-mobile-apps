
<footer class="bg-orange-700 text-neutral-300 text-center py-2">
  <p class="text-sm">© 2023 Velomac Cars </p>
</footer>
