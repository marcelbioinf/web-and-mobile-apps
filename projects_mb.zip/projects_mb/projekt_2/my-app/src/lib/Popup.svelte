<!-- Popup.svelte -->
<script>

  export let onClose;

  function closePopup() {
    onClose();
  }

</script>

<style>
  .popup-overlay {
    background-color: rgba(0, 0, 0, 0.7);
  }
</style>

<div class="popup-overlay flex justify-center items-center fixed w-full h-full top-0 left-0">
  <div class="bg-neutral-300 p-4 md:p-10 rounded-md  w-3/4 md:w-1/2">

    <button on:click={closePopup} class="bg-orange-700 p-2 rounded-md hover:opacity-70 text-neutral-800 font-semibold drop-shadow-md">Close</button>

    <h1 class=" text-2xl md:text-3xl text-neutral-800 text-center my-5">Add new car</h1>

    <form action="?/save" method="post" class="grid grid-cols-3 gap-4 md:gap-6">

      <label for="marka">
        <span class="block mb-2">Brand:</span>
        <input name="marka" required type="text" class="border border-orange-700 p-1 md:p-2 w-3/4 md:w-4/5" />
      </label>

      <label for="model">
        <span class="block mb-2">Model:</span>
        <input name="model" type="text" class="border border-orange-700 p-1 md:p-2 w-3/4 md:w-4/5"  />
      </label>

      <label for="year">
        <span class="block mb-2">Year:</span>
        <input name="year" type="number" class="border border-orange-700 p-1 md:p-2 w-3/4 md:w-4/5"  />
      </label>

      <label for="color">
        <span class="block mb-2">Color:</span>
        <input name="color" type="text" class="border border-orange-700 p-1 md:p-2 w-3/4 md:w-4/5"  />
      </label>

      <label for="mileage">
        <span class="block mb-2">Mileage:</span>
        <input name="mileage" type="number" class="border border-orange-700 p-1 md:p-2 w-3/4 md:w-4/5"  />
      </label>

      <label for="engine">
        <span class="block mb-2">Engine:</span>
        <input name="engine" type="text" class="border border-orange-700 p-1 md:p-2 w-3/4 md:w-4/5"  />
      </label>

      <label for="HP">
        <span class="block mb-2">Horse Power:</span>
        <input name="HP" type="number" class="border border-orange-700 p-1 md:p-2 w-3/4 md:w-4/5"  />
      </label>

      <label for="Nm">
        <span class="block mb-2">Max Torque:</span>
        <input name="Nm" type="number" class="border border-orange-700 p-1 md:p-2 w-3/4 md:w-4/5"  />
      </label>

      <label for="top_speed">
        <span class="block mb-2">Top speed:</span>
        <input name="top_speed" type="number" class="border border-orange-700 p-1 md:p-2 w-3/4 md:w-4/5"  />
      </label>

      <label for="zero_hun">
        <span class="block mb-2">0-100 km/h:</span>
        <input name="zero_hun" type="number" class="border border-orange-700 p-1 md:p-2 w-3/4 md:w-4/5"  />
      </label>

      <label for="price">
        <span class="block mb-2">Price:</span>
        <input name="price" type="number" class="border border-orange-700 p-1 md:p-2 w-3/4 md:w-4/5"  />
      </label>

      <label for="image">
        <span class="block mb-2">Image</span>
        <input name="image" type="text" class="border border-orange-700 p-1 md:p-2 w-3/4 md:w-4/5" />
      </label>

      <button type="submit" class="col-span-3 w-1/3 mx-auto bg-orange-700 p-3 mt-5 rounded-md hover:opacity-70 text-neutral-800 font-bold text-xl drop-shadow-md"> Save </button>

    </form>
  </div>
</div>



<!-- 
  let marka = '';
  let model = '';
  let color = '';
  let engine = '';
  let year = 0;
  let mileage = 0;
  let HP = 0;
  let Nm = 0;
  let top_speed = 0;
  let zero_hun = 0;
  let price = 0;
  let image = '';-->
