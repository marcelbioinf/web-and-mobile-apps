<script>

    export let id;
    export let marka;
    export let model;
    export let year;
    // export let color;
    // export let mileage;
    // export let engine;
    // export let HP;
    // export let Nm;
    // export let top_speed;
    // export let zero_hun;
    // export let price;
    export let image;


</script>


<a href={`/cars/${id}`} class="border-2 border-orange-700 pb-4 group hover:bg-orange-700 hover:opacity-80 hover:text-neutral-300">
  <img src={image} alt="{marka}" class="w-full h-[160px] object-cover mx-auto" />
  <h1 class="px-4 py-1 mt-2 text-center text-2xl text-neutral-300 group-hover:text-neutral-800">{marka}</h1>
  <p class="text-base text-center text-orange-700 group-hover:text-neutral-300">{year} {model}</p>
</a>
