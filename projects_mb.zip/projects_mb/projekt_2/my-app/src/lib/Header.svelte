
<header class="bg-orange-700 px-4 py-2">
  <nav>
    <ul class="flex gap-10 justify-center text-lg lg:text-xl text-neutral-800 font-semibold">
      <li class="hover:text-neutral-300"><a href="/">Home</a></li>
      <li class="hover:text-neutral-300"><a href="/cars">Our cars</a></li>
      <li class="hover:text-neutral-300"><a href="/about">About Us</a></li>
      <li class="hover:text-neutral-300"><a href="/contact">Contact</a></li>
    </ul>
  </nav>
</header>
