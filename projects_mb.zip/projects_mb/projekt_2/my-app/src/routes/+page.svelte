<script>

    export let data;
    const { cars } = data;

</script>


<div class="bg-neutral-800 h-full">

        <section class="bg-cover bg-center bg-[url('rari.jpg')] pb-48 text-center">
            <div class="text-6xl pt-20 text-orange-700 font-bold shadow-xl">Velomac Cars</div>
            <h1 class="text-4xl font-bold text-neutral-300 mt-2 pb-10 shadow-lg">Drive in Style, Drive with Power</h1>
            <a href="./cars" class="bg-orange-700 border-2 border-orange-700 text-neutral-900 py-3 px-6 text-lg font-semibold rounded-full hover:bg-neutral-800 hover:text-neutral-300 hover:border-4 transition duration-500">Explore Our Collection</a>
        </section>
    
        <section class="container mx-auto my-8">
            <h2 class="text-3xl font-bold mb-4 px-8 text-orange-700">Featured Cars</h2>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <a href="/cars/{cars[0].id}" class="flex">
                    <div class="bg-neutral-800 text-neutral-300 p-5 rounded-lg shadow-md border-4 border-orange-700 hover:border-2 hover:border-orange-700 hover:bg-orange-700 hover:text-neutral-900 transition duration-500">
                        <img src="{cars[0]?.image}" alt="Car 1" class="w-full h-48 object-cover mb-4 rounded-md">
                        <h3 class="text-xl font-bold mb-2">{cars[0]?.marka} {cars[0]?.model} {cars[0]?.year}</h3>
                        <p class="text-lg">Our absolute treasure. Timeless and unstopable.</p>
                    </div>
                </a>
                <a href="/cars/{cars[3].id}" class="flex">
                    <div class=" bg-neutral-800 text-neutral-300 p-5 rounded-lg shadow-md border-4 border-orange-700 hover:border-2 hover:border-orange-700 hover:bg-orange-700 hover:text-neutral-900 transition duration-500">
                        <img src="{cars[3]?.image}" alt="Car 2" class="w-full h-48 object-cover mb-4 rounded-md">
                        <h3 class="text-xl font-bold mb-2">{cars[3]?.marka} {cars[3]?.model} {cars[3]?.year}</h3>
                        <p class="text-lg">Ultimate luxury and comfort. Feels more like a yacht</p>
                    </div>
                </a>
                <a href="/cars/{cars[2].id}" class="flex">
                    <div class=" bg-neutral-800 text-neutral-300 p-5 rounded-lg shadow-md border-4 border-orange-700 hover:border-2 hover:border-orange-700 hover:bg-orange-700 hover:text-neutral-900 transition duration-500">
                        <img src="{cars[2]?.image}" alt="Car 3" class="w-full h-48 object-cover mb-4 rounded-md">
                        <h3 class="text-xl font-bold mb-2">{cars[2]?.marka} {cars[2]?.model} {cars[2]?.year}</h3>
                        <p class="text-lg">Cruise around in James Bond style cabrio.</p>
                    </div>
                </a>
            </div>
        </section>
    
        <section class="bg-neutral-700 py-12 mt-16">
            <div class="container mx-auto text-center">
                <h2 class="text-3xl font-bold mb-4 text-orange-700">Our Exclusive Services</h2>
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 px-10 pt-4">
                    <div class="bg-white p-6 rounded-lg shadow-md ">
                        <h3 class="text-xl font-bold mb-2">Car dealership</h3>
                        <p class="text-gray-700">We can not only sell you a car but also sell your car.</p>
                        <a href="./" class="text-orange-700 hover:underline mt-2 inline-block">Learn More</a>
                    </div>
                    <div class="bg-white p-6 rounded-lg shadow-md ">
                        <h3 class="text-xl font-bold mb-2">Car rental</h3>
                        <p class="text-gray-700">You can rent our cars for an unforgettable experience.</p>
                        <a href="./" class="text-orange-700 hover:underline mt-2 inline-block">Learn More</a>
                    </div>
                    <div class="bg-white p-6 rounded-lg shadow-md ">
                        <h3 class="text-xl font-bold mb-2">Concierge Service</h3>
                        <p class="text-gray-700">We can deliever you the most prestigious chauffeur.</p>
                        <a href="./" class="text-orange-700 hover:underline mt-2 inline-block">Learn More</a>
                    </div>
                </div>
            </div>
        </section>
    
        <section class="container mx-auto mt-12 pb-16 px-10">
            <h2 class="text-3xl font-bold mb-4 text-orange-700">About Us</h2>
            <p class="text-neutral-300 mb-4 text-xl">A brief history of Velomac and its commitment to providing top-notch luxury and sports cars</p>
            <a href="/about" class="hover:text-orange-700 hover:underline text-neutral-300 text-lg">See more...</a>
        </section>

</div>