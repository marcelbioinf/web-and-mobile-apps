<script>
    import LeftArrowIcon from "$lib/LeftArrowIcon.svelte";
    import { goto } from "$app/navigation";
  
    export let data;
    const { car } = data;

    const DeleteCar= async () => {

        const confirmDelete = confirm('Are you sure you want to delete this car?');
        if (!confirmDelete) {
        return;
        }

        const res = await fetch(`/api/cars/${car.id}`, {
            method: "DELETE",
        });

        if (res.ok) {
            const d = await res.json();
            if (!d.status) {
                console.log('Data not deleted!');
                return;
            } else {
                console.log('Data deleted: ' + d.car.id );
                goto("/cars/");
            }
        }
    }

    let editPlane = false;

    function EditCar() {
        editPlane = true;
    }

    function CloseEditCar() {
        editPlane = false;
    }

</script>


<div class="bg-neutral-800 flex flex-col">
    <h1 class="text-3xl md:text-4xl p-8 lg:mx-auto text-neutral-300">{car?.marka} {car?.model} {car?.year}</h1>
    <div class="flex flex-col gap-4">
        <img src={car?.image} alt="" class="w-5/6 mx-auto md:w-4/5 lg:w-3/5 h-full object-cover border-2 border-orange-700">
        <h2 class="w-2/6 mt-3 mx-auto text-xl md:text-2xl text-center border-2 rounded-md border-orange-700 p-2 md:flex md:justify-center md:items-center text-neutral-800 font-semibold bg-orange-700">Price: <br> ${car?.price}</h2>
    </div>
    <div class="mx-auto mt-6 text-xl lg:text-2xl text-neutral-300">Color: {car?.color}</div>
    <div class="mx-auto mt-6 text-xl lg:text-2xl text-neutral-300">Performance:</div>
    <div class="grid grid-cols-2 md:grid-cols-3 gap-9 mx-auto mt-6 xl:mt-10">
        <div class="p-2 md:p-4 rounded-md border-2 border-orange-700 text-center text-lg xl:text-xl text-neutral-300">Engine: <br> {car?.engine}</div>
        <div class="p-2 md:p-4 rounded-md border-2 border-orange-700 text-center text-lg xl:text-xl text-neutral-300">Horse Power: <br> {car?.HP}HP</div>
        <div class="p-2 md:p-4 rounded-md border-2 border-orange-700 text-center text-lg xl:text-xl text-neutral-300">Max Torque: <br> {car?.Nm}Nm</div>
        <div class="p-2 md:p-4 rounded-md border-2 border-orange-700 text-center text-lg xl:text-xl text-neutral-300">Top speed: <br> {car?.top_speed} km/h</div>
        <div class="p-2 md:p-4 rounded-md border-2 border-orange-700 text-center text-lg xl:text-xl text-neutral-300">0-100 km/h: <br> {car?.zero_hun} s</div>
        <div class="p-2 md:p-4 rounded-md border-2 border-orange-700 text-center text-lg xl:text-xl text-neutral-300">Mileage: <br> {car?.mileage} km</div>
    </div>

    <div class="mt-20 bg-neutral-500 pt-3">
        {#if !editPlane}
            <h2 class="text-center text-xl font-bold">Delete or edit this car</h2>
            <div class="flex justify-center gap-16 p-3">
                <button type="button" class="hover:opacity-40"
                on:click={DeleteCar}
                data-te-toggle="tooltip"
                data-te-placement="bottom"
                data-te-ripple-init
                data-te-ripple-color="light"
                title="Delete this car">
                <svg width="42px" height="64px" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <path d="M10 12V17" stroke="#000000" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path> <path d="M14 12V17" stroke="#000000" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path> <path d="M4 7H20" stroke="#000000" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path> <path d="M6 10V18C6 19.6569 7.34315 21 9 21H15C16.6569 21 18 19.6569 18 18V10" stroke="#000000" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path> <path d="M9 5C9 3.89543 9.89543 3 11 3H13C14.1046 3 15 3.89543 15 5V7H9V5Z" stroke="#000000" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path> </g></svg>            </button>

                <button type="button" class="hover:opacity-40"
                on:click={EditCar}
                data-te-toggle="tooltip"
                data-te-placement="bottom"
                data-te-ripple-init
                data-te-ripple-color="light"
                title="Edit this car">
                <svg fill="#000000" width="38px" height="64px" viewBox="0 0 1920 1920" xmlns="http://www.w3.org/2000/svg" transform="rotate(90)" stroke="#000000" stroke-width="34.559999999999995"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <path d="M277.974 49.076c65.267-65.379 171.733-65.49 237.448 0l232.186 232.187 1055.697 1055.809L1919.958 1920l-582.928-116.653-950.128-950.015 79.15-79.15 801.792 801.68 307.977-307.976-907.362-907.474L281.22 747.65 49.034 515.464c-65.379-65.603-65.379-172.069 0-237.448Zm1376.996 1297.96-307.977 307.976 45.117 45.116 384.999 77.023-77.023-385-45.116-45.116ZM675.355 596.258l692.304 692.304-79.149 79.15-692.304-692.305 79.149-79.15ZM396.642 111.88c-14.33 0-28.547 5.374-39.519 16.345l-228.94 228.94c-21.718 21.718-21.718 57.318 0 79.149l153.038 153.037 308.089-308.09-153.037-153.036c-10.972-10.971-25.301-16.345-39.63-16.345Z" fill-rule="evenodd"></path> </g></svg>            </button>
            </div>
        {/if}
        {#if editPlane}
            <button on:click={CloseEditCar} class="bg-orange-700 p-2 md:px-4 text-xl rounded-md hover:opacity-70 text-neutral-800 font-semibold drop-shadow-md mt-8 ml-10">Close</button>
            <h2 class="text-center text-xl font-bold">Edit this car</h2>
            <div class="flex flex-col items-center p-3 pb-6">
                <form action="?/update" method="post" class="grid grid-cols-3 gap-4 md:gap-6">

                    <label for="marka">
                    <span class="block mb-2">Brand:</span>
                    <input name="marka" value={car?.marka} required type="text" class="border border-orange-700 p-1 md:p-2 w-3/4 md:w-4/5" />
                    </label>
            
                    <label for="model">
                    <span class="block mb-2">Model:</span>
                    <input name="model" value={car?.model} type="text" class="border border-orange-700 p-1 md:p-2 w-3/4 md:w-4/5"  />
                    </label>
            
                    <label for="year">
                    <span class="block mb-2">Year:</span>
                    <input name="year" value={car?.year} type="number" class="border border-orange-700 p-1 md:p-2 w-3/4 md:w-4/5"  />
                    </label>
            
                    <label for="color">
                    <span class="block mb-2">Color:</span>
                    <input name="color" value={car?.color} type="text" class="border border-orange-700 p-1 md:p-2 w-3/4 md:w-4/5"  />
                    </label>
            
                    <label for="mileage">
                    <span class="block mb-2">Mileage:</span>
                    <input name="mileage" value={car?.mileage} type="number" class="border border-orange-700 p-1 md:p-2 w-3/4 md:w-4/5"  />
                    </label>
            
                    <label for="engine">
                    <span class="block mb-2">Engine:</span>
                    <input name="engine" value={car?.engine} type="text" class="border border-orange-700 p-1 md:p-2 w-3/4 md:w-4/5"  />
                    </label>
            
                    <label for="HP">
                    <span class="block mb-2">Horse Power:</span>
                    <input name="HP" value={car?.HP} type="number" class="border border-orange-700 p-1 md:p-2 w-3/4 md:w-4/5"  />
                    </label>
            
                    <label for="Nm">
                    <span class="block mb-2">Max Torque:</span>
                    <input name="Nm" value={car?.Nm} type="number" class="border border-orange-700 p-1 md:p-2 w-3/4 md:w-4/5"  />
                    </label>
            
                    <label for="top_speed">
                    <span class="block mb-2">Top speed:</span>
                    <input name="top_speed" value={car?.top_speed} type="number" class="border border-orange-700 p-1 md:p-2 w-3/4 md:w-4/5"  />
                    </label>
            
                    <label for="zero_hun">
                    <span class="block mb-2">0-100 km/h:</span>
                    <input name="zero_hun" value={car?.zero_hun} type="number" class="border border-orange-700 p-1 md:p-2 w-3/4 md:w-4/5"  />
                    </label>
            
                    <label for="price">
                    <span class="block mb-2">Price:</span>
                    <input name="price" value={car?.price} type="number" class="border border-orange-700 p-1 md:p-2 w-3/4 md:w-4/5"  />
                    </label>
            
                    <label for="image">
                    <span class="block mb-2">Image</span>
                    <input name="image" value={car?.image} type="text" class="border border-orange-700 p-1 md:p-2 w-3/4 md:w-4/5" />
                    </label>
            
                    <button type="submit" class="col-span-3 w-1/3 mx-auto bg-orange-700 p-3 mt-5 rounded-md hover:opacity-70 text-neutral-800 font-bold text-xl drop-shadow-md"> Save </button>
        
                </form>
            </div>
        {/if}
    </div>

    <div class="text-center flex justify-center mt-12 mb-9">
        <a href="/cars" class="mx-auto flex items-center hover:opacity-60">
            <LeftArrowIcon /> Back
        </a>
    </div>
</div>



  