import { PrismaClient } from '@prisma/client';

/** @type {import('./$types').PageServerLoad} */
export async function load({ params }) {

  const prisma = new PrismaClient();

  const car = await prisma.car.findUnique({
    where: {
      id: Number(params.id)
    }
  });

  await prisma.$disconnect();

  return {
    car
  }
}

/** @type {import('./$types').Actions} */
export const actions = {
  update: async ({ request, params }) => {

    const prisma = new PrismaClient();
    
    try {
      const data_form = await request.formData();

      const car = {
        marka: data_form.get('marka'),
        model: data_form.get('model'),
        color: data_form.get('color'),
        engine: data_form.get('engine'),
        mileage: parseInt(data_form.get('mileage')),
        HP: parseInt(data_form.get('HP')),
        image: data_form.get('image'),
        Nm: parseInt(data_form.get('Nm')),
        top_speed: parseInt(data_form.get('top_speed')),
        zero_hun: parseFloat(data_form.get('zero_hun')),
        price: parseInt(data_form.get('price')),
      };

      // If params.id exists, it means it's an update operation
      if (params.id) {
        const carId = Number(params.id);
        const existingCar = await prisma.car.findUnique({
          where: {
            id: carId,
          },
        });

        if (!existingCar) {
          return {
            status: 404,
            body: { error: 'Car not found' },
          };
        }

        // Update the existing car
        const updatedCar = await prisma.car.update({
          where: {
            id: carId,
          },
          data: car,
        });

        return {
          status: 200,
          body: { message: 'Car updated successfully', car: updatedCar },
        };
      } else {
        console.log('Car not found')
      }
    } catch (error) {
      console.error('Error saving car:', error);
      return {
        status: 500,
        body: { error: 'Internal Server Error' },
      };
    } finally {
      await prisma.$disconnect();
    }
  },
};

