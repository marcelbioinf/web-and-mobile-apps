import { PrismaClient } from '@prisma/client';

/** @type {import('./$types').PageServerLoad} */
export async function load() {

  const prisma = new PrismaClient();

  /**
   * @type {any[]}
   */
  let cars = [];

  cars = await prisma.car.findMany();

  await prisma.$disconnect();

  return {
    cars
  }
}



/** @type {import('./$types').Actions} */
export const actions = {
  save: async ({request}) => {

    const data_form = await request.formData();

    const car = {
      marka: data_form.get('marka'),
      model: data_form.get('model'),
      color: data_form.get('color'),
      engine: data_form.get('engine'),
      mileage: parseInt(data_form.get('mileage')),
      HP: parseInt(data_form.get('HP')),
      image: data_form.get('image'),
      Nm: parseInt(data_form.get('Nm')),
      top_speed: parseInt(data_form.get('top_speed')),
      zero_hun: parseFloat(data_form.get('zero_hun')),
      price: parseInt(data_form.get('price')),
    }

    const prisma = new PrismaClient();

    const result = await prisma.car.create({
      data: car,
    });

    await prisma.$disconnect();
  },
};



