<script>
  import Car from "$lib/components/Car.svelte";
  import Popup from "$lib/Popup.svelte";
  
  export let data;
  
  const { cars } = data;

  let isPopupOpen = false;

  function openPopup() {
    isPopupOpen = true;
  }

  function closePopup() {
    isPopupOpen = false;
  }

</script>
  
  
<div class="bg-neutral-800 h-full">
  <div class="pt-8 w-4/5 mx-auto flex justify-between">
    <h1 class="text-3xl text-neutral-300">Our car collection</h1>

    <button id="openFormButton" type="button" class="hover:opacity-50 -mt-3"
    on:click={openPopup}
    data-te-toggle="tooltip"
    data-te-placement="bottom"
    data-te-ripple-init
    data-te-ripple-color="light"
    title="Add a car">
        <svg width="40px" height="64px" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <g id="Edit / Add_Plus_Square"> <path id="Vector" d="M8 12H12M12 12H16M12 12V16M12 12V8M4 16.8002V7.2002C4 6.08009 4 5.51962 4.21799 5.0918C4.40973 4.71547 4.71547 4.40973 5.0918 4.21799C5.51962 4 6.08009 4 7.2002 4H16.8002C17.9203 4 18.4801 4 18.9079 4.21799C19.2842 4.40973 19.5905 4.71547 19.7822 5.0918C20.0002 5.51962 20.0002 6.07967 20.0002 7.19978V16.7998C20.0002 17.9199 20.0002 18.48 19.7822 18.9078C19.5905 19.2841 19.2842 19.5905 18.9079 19.7822C18.4805 20 17.9215 20 16.8036 20H7.19691C6.07899 20 5.5192 20 5.0918 19.7822C4.71547 19.5905 4.40973 19.2842 4.21799 18.9079C4 18.4801 4 17.9203 4 16.8002Z" stroke="#e5e5e5" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path> </g> </g></svg>
    </button>
  </div>

  {#if isPopupOpen}
    <Popup onClose={closePopup} />
  {/if}

  <div class="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-6 pt-6 pb-9 w-4/5 mx-auto">
    {#each cars as car}
      <Car {...car} />
    {/each}
  </div>

</div>


