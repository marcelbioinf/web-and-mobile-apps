import { PrismaClient } from '@prisma/client';

/** @type {import('./$types').PageServerLoad} */
export async function load() {
  const prisma = new PrismaClient();

  try {
    const cars = await prisma.car.findMany({
      take: 4, 
    });

    return {
      cars,
    };
  } finally {
    await prisma.$disconnect();
  }
}
