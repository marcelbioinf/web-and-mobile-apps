
<div class="bg-neutral-500 h-full p-10 border-3 border-neutral-300">

    <div class="md:w-4/5 mx-auto p-8 border-4 border-orange-700 rounded-lg shadow-lg">
        <h1 class="text-3xl font-bold mb-6">About VeloMac Cars</h1>

        <p class="text-gray-800 mb-6">Welcome to VeloMac Cars, where luxury meets performance, and excellence is our driving force. At VeloMac, we redefine the automotive experience, bringing you a curated selection of the finest luxury cars that embody sophistication, power, and elegance.</p>

        <h2 class="text-2xl font-bold mb-4">Our Passion for Luxury</h2>

        <p class="text-gray-800 mb-6">VeloMac Cars was born out of a shared passion for exceptional automobiles. As avid enthusiasts of the automotive world, our founders envisioned creating a haven for those who appreciate the artistry and engineering behind luxury vehicles. Every car in our showroom is handpicked, reflecting our commitment to delivering unparalleled quality and craftsmanship.</p>

        <h2 class="text-2xl font-bold mb-4">The VeloMac Difference</h2>

        <p class="text-gray-800 mb-6">What sets VeloMac Cars apart is not just the prestige of the brands we carry but our unwavering commitment to providing an extraordinary customer experience. Our showroom is a sanctuary for car connoisseurs, meticulously designed to showcase each vehicle's unique personality and features. From the sleek lines of the exterior to the opulence of the interior, every detail is a testament to the uncompromising standards we uphold.</p>

        <h2 class="text-2xl font-bold mb-4">Expertise You Can Trust</h2>

        <p class="text-gray-800 mb-6">At VeloMac, our team of automotive experts is dedicated to guiding you through the selection process with knowledge and integrity. Whether you are seeking a performance-driven sports car, a luxurious sedan, or a cutting-edge SUV, our professionals are here to ensure you make an informed decision that aligns with your desires and lifestyle.</p>

        <h2 class="text-2xl font-bold mb-4">Unrivaled Luxury Brands</h2>

        <p class="text-gray-800 mb-6">VeloMac Cars proudly represents the most prestigious names in the automotive world. From the timeless elegance of classic luxury brands to the avant-garde innovation of the latest models, our inventory boasts an impressive collection that caters to diverse tastes. Each vehicle on our lot is a masterpiece in its own right, promising a driving experience that transcends the ordinary.</p>

        <h2 class="text-2xl font-bold mb-4">Beyond the Showroom</h2>

        <p class="text-gray-800 mb-6">At VeloMac, our commitment to excellence extends beyond the showroom floor. We offer a range of personalized services, including expert maintenance and customization options, ensuring that your luxury car continues to exceed expectations long after your purchase. Our service center is staffed with skilled technicians who share our dedication to perfection.</p>

        <h2 class="text-2xl font-bold mb-4">Join the VeloMac Experience</h2>

        <p class="text-gray-800 mb-6">VeloMac Cars invites you to embark on a journey where luxury, performance, and passion converge. Whether you are a seasoned collector or a first-time luxury car buyer, we invite you to explore our showroom and discover the extraordinary. At VeloMac, the road to automotive excellence begins with you.</p>

        <p class="text-gray-800">Come, experience the art of driving at VeloMac Cars — where every mile is a masterpiece.</p>
    </div>

</div>