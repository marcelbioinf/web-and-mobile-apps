<script>
    import Header from "$lib/Header.svelte"
    import Footer from "$lib/Footer.svelte";
    import "../app.pcss";
</script>


<Header/>


<slot />


<Footer />
