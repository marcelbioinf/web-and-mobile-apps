<!-- @format -->
<script>
  function onClick() {
    alert('Message sent')
  }

</script>

<div class="bg-neutral-800 h-full">

  <div class="bg-neutral-500 p-6">
    <h2 class="text-2xl font-bold mb-4 text-center">Visit Us</h2>
    <div class="flex gap-10 md:gap-14 justify-center">
      <div class="border-2 border-orange-700 p-3 rounded-md mt-3 shadow-md">
        <p class="text-neutral-800 mb-2">VeloMac Cars Showroom</p>
        <p class="text-neutral-800 mb-2">7969 Santa Monica Blvd</p>
        <p class="text-neutral-800 mb-2">Los Angeles, California</p>
        <p class="text-neutral-800 mb-2">081 212 3353 </p>
      </div>
      <div class="border-2 border-orange-700 p-3 rounded-md mt-3 shadow-md">
        <p class="text-neutral-800 mb-2">VeloMac Dealership</p>
        <p class="text-neutral-800 mb-2">712 Upper East Side 6032</p>
        <p class="text-neutral-800 mb-2">NYC, New York</p>
        <p class="text-neutral-800 mb-2">111 222 3333 </p>
      </div>
   </div>

    <h2 class="text-2xl font-bold mb-4 mt-10 text-center">Contact Us</h2>
    <div class="flex items-center flex-col">
      <p class="text-neutral-800 mb-2">Phone: (555) 123-4567</p>
      <p class="text-neutral-800 mb-2 hover:text-neutral-300">Email: info@velomaccars.com</p>
    </div>
  </div>

  <h1 class="text-3xl md:text-4xl text-orange-700 text-center py-8">Contact us with a form</h1>
    <form on:submit|preventDefault={onClick} class="grid grid-cols-2 gap-6 p-4 w-3/4 mx-auto text-orange-700">
      <label for="first_name">
        <span class="block mb-2 text-xl">First Name</span>
        <input name="first_name" type="text" class="border border-gray-300 rounded-md p-1 w-full" />
      </label>
      <label for="last_name">
        <span class="block mb-2 text-xl">Last Name</span>
        <input name="last_name" type="text" class="border border-gray-300 rounded-md p-1 w-full" />
      </label>
      <div class="col-span-2">
        <label for="mail">
          <span class="block mb-2 text-xl">Mail</span>
          <input name="mail" type="text" class="border border-gray-300 rounded-md p-1 w-3/4" />
        </label>
      </div>
      <div class="col-span-2 row-span-2">
        <label for="message">
          <span class="block mb-2 text-xl">Your message</span>
          <input name="message" type="text" class="border border-gray-300 rounded-md p-10 w-full " />
        </label>
      </div>

      <button type="submit" class="col-span-2 mt-3 bg-orange-700 rounded-md md:w-1/6 p-4 mx-auto text-neutral-800 text-xl font-bold mb-7 hover:opacity-70 hover:text-neutral-300"> Send </button>
    </form>

</div>



