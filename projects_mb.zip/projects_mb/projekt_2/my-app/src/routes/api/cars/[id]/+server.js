import { PrismaClient } from "@prisma/client";

export const DELETE = async ({ params }) => {
  let result;
  let status = false;

  const prisma = new PrismaClient();

  result = await prisma.car.delete({
    where: {
      id: Number(params.id)
    }
  });

  await prisma.$disconnect();

  return new Response(JSON.stringify({
    status: result ? true : false,
    car: result
  }))
}
