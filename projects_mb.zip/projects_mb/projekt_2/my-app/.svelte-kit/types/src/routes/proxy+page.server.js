// @ts-nocheck
import { PrismaClient } from '@prisma/client';

/** */
export async function load() {
  const prisma = new PrismaClient();

  try {
    const cars = await prisma.car.findMany({
      take: 4, 
    });

    return {
      cars,
    };
  } finally {
    await prisma.$disconnect();
  }
}
