/** @type {import('tailwindcss').Config}*/
const config = {
  content: ["./src/**/*.{html,js,svelte,ts}"],

  theme: {
    extend: {
      colors: {
        grey1: '#55535B',
        pale: '#EFEDE4',
        grey2: '#3E5058',
        purple1: '#3D3D60'
      }
    },
  },

  plugins: []
};

module.exports = config;