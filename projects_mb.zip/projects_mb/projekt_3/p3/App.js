import * as React from 'react';
import { View, StyleSheet, TextInput, FlatList, Text, TouchableOpacity, KeyboardAvoidingView } from 'react-native';
import * as Speech from 'expo-speech';

export default function App() {
  const [inputText, setInputText] = React.useState('');
  const [spokenTexts, setSpokenTexts] = React.useState([]);
  const [isInputActive, setIsInputActive] = React.useState(false);

  const handleFocus = () => {
    setIsInputActive(true);
  };

  const handleBlur = () => {
    setIsInputActive(false);
  };

  const clearSpokenTexts = () => {
    setSpokenTexts([]);
  };

  const speak = () => {
    Speech.speak(inputText);
    setSpokenTexts([...spokenTexts, inputText]);
    setInputText(''); 
  };

  return (
    <KeyboardAvoidingView style={styles.container} behavior="padding">
      <View style={styles.clearButtonContainer}>
        <TouchableOpacity onPress={clearSpokenTexts}>
          <Text style={styles.clearButtonText}>Clear</Text>
        </TouchableOpacity>
      </View>
      <Text style={styles.spokenTextTitle}>Spoken Texts:</Text>
      <FlatList
        data={spokenTexts}
        renderItem={({ item }) => <Text style={styles.spokenText}>{item}</Text>}
        keyExtractor={(item, index) => index.toString()}
      />
      <View style={styles.container2}>
        <TextInput
          style={[styles.input, isInputActive && styles.inputActive]}
          placeholder={inputText ? '' : 'Say something...'}
          placeholderTextColor="#d4d4d4"
          onChangeText={(text) => setInputText(text)}
          value={inputText}
          onFocus={handleFocus}
          onBlur={handleBlur}
          keyboardAppearance="dark"
        />
        <TouchableOpacity style={styles.button} onPress={speak}>
          <Text style={styles.buttonText}>Press to read the text</Text>
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#3f3f46',
    padding: 8,
  },
  container2: {
    marginBottom: 60
  },
  button: {
    backgroundColor: '#6d28d9',
    padding: 10,
    borderRadius: 15,
    width: 250,
    marginLeft: 'auto',
    marginRight: 'auto',
    alignItems: 'center',
  },
  buttonText: {
    color: 'white',
    fontSize: 18,
  },
  input: {
    height: 45,
    borderColor: '#6d28d9',
    borderRadius: 25,
    borderWidth: 4,
    marginBottom: 20,
    paddingLeft: 10,
    paddingRight: 10,
    fontSize: 18,
    color: 'white'
  },
  inputActive: {
    borderColor: '#eab308', 
    borderWidth: 3,
  },
  spokenTextTitle: {
    fontSize: 21,
    fontWeight: 'bold',
    marginTop: 70,
    textAlign: 'center',
    color: '#eab308',
    marginBottom: 20,
  },
  spokenText: {
    fontSize: 17,
    left: 10,
    color: '#d4d4d4',
  },
  clearButtonContainer: {
    position: 'absolute',
    top: 58,
    left: 20,
    zIndex: 1,
    backgroundColor: '#eab308',
    borderRadius: 12,
    padding: 5,
    paddingHorizontal: 8,
  },
  clearButtonText: {
    color: '#6d28d9',
    fontSize: 18,
  },
});
